from getpass import getpass

def menu():
      while True:
           print("Admin-Noor")
           print("\033[1;93m")
           print("Log-In Sir")
           print("\033[1;96m")
           try:
                x = str(input('\033[1;92mUsername \033[1;93m: '))
                print("")
                e = getpass('\033[1;92mPassword \033[1;93m: ')
                print ("")
                if x=="Noor" and e=="freakin":
                   print('')
                   print("")
                   print(' Welcome ')
                   print("")
                   break
                else:
                      print("")
                      print("")
                      print("")
                      print("")
                      print("\033[1;91mGalat-Jawab")
                      print("")
           except Exception:
                      
                      print("")
                      print("")
                      print("")
                      print("")
                      print("")
                      print("\033[1;91m     Wrong Password")
           except KeyboardInterrupt:
                      print("")
                      print("")
                      print("")
                      print("")
                      print("")
                      print("\033[1;91m     Wrong Password")
menu()
